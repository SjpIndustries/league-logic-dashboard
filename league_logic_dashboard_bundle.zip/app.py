
import streamlit as st
import gspread
from google.oauth2 import service_account

# Google Sheets authentication
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = service_account.Credentials.from_service_account_info(
    st.secrets["gcp_service_account"], scopes=scope
)
client = gspread.authorize(creds)

# Open the Google Sheet and worksheet
sheet = client.open("LeagueLogic Dashboard")
worksheet = sheet.worksheet("Prediction Log")

# Load and display data
data = worksheet.get_all_records()
st.title("🏉 LeagueLogic V2.1 — Prediction Log")
st.dataframe(data)
